<b><h1>Note: This tool will not scan your URLs, but print each payload appended to the URL.</h1></b>
<b><h1>নোট: এই টুলটি আপনার ইউআরএল স্ক‌্যান করবে না, বরং ইউআরএল এর সাথে প্রতিটি পেলোড যুক্ত করে প্রিন্ট করবে।</h1></b>

#### All type of URL injection fuzzer https://freelancermijan.github.io/urlfuzzer/

<img src="./images/instructions.png" >

<p>This is online based URL Fuzzer  tool. It's only fuzz ONE parameter at a time.</p>

## Features. 

- **Fuzzing URLs:**
- **Custom payload option:**
- **Custom payload from online link:**
- **XSS Fuzzing:**
- **SQLi Fuzzing:**
- **LFI Fuzzing:**
- **Command Injection Fuzzing:**
- **All type of URL based injection attacks fuzzing:**
